//
//  UIView+Extension.m
//  DobeFM
//
//  Created by Craig Liao on 15/7/16.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import "UIView+Extension.h"

@implementation UIView (Extension)


//- initwithButton:(UIButton *)button imageView:(UIImageView *)imageView frame:(CGRect)frame imageName:(NSString *)imageName edgeInset:(UIEdgeInsets)edgeInset title:(NSString *)title{
//    if (self = [super init]) {
//        button = [UIButton buttonWithType:UIButtonTypeCustom];
//        button.frame = frame;
//        [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
//        [button setImageEdgeInsets:edgeInset];
//        
//        [button setTitle:title forState:UIControlStateNormal];
//        [button setTitleEdgeInsets:edgeInset];
//        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        [button setTitle:title forState:UIControlStateSelected];
//        [button setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
//        [imageView addSubview:button];
//    }
//    return self;
//}

@end
