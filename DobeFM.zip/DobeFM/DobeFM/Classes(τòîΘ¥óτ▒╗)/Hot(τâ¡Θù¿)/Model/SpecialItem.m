//
//  SpecialItem.m
//  iTing
//
//  Created by Craig Liao on 15/7/4.
//  Copyright (c) 2015年 Craig Liao. All rights reserved.
//

#import "SpecialItem.h"

@implementation SpecialItem

- (id)initWithCoverBig:(NSString *)coverBig releaseAt:(NSNumber *)releaseAt spcialID:(NSNumber *)spcialID subTitle:(NSString *)subTitle titleString:(NSString *)titleString hot:(BOOL)hot{
    if (self = [super init]) {
        self.coverBig = coverBig;
        self.releaseAt = releaseAt;
        self.spcialID = spcialID;
        self.subTitle = subTitle;
        self.titleString = titleString;
        self.hot = hot;
    }
    return self;
}

+ (id)specialCoverBig:(NSString *)coverBig releaseAt:(NSNumber *)releaseAt spcialID:(NSNumber *)spcialID subTitle:(NSString *)subTitle titleString:(NSString *)titleString hot:(BOOL)hot{
    SpecialItem *spcItem = [[[SpecialItem alloc] initWithCoverBig:coverBig releaseAt:releaseAt spcialID:spcialID subTitle:subTitle titleString:titleString hot:hot] autorelease];
    
    return spcItem;
}

- (void)dealloc{
    [_coverBig release];
    [_releaseAt release];
    [_spcialID release];
    [_subTitle release];
    [_titleString release];
    [super dealloc];
}

@end
