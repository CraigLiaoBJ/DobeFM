//
//  MoreTableViewController.h
//  iTing
//
//  Created by Craig Liao on 15/7/14.
//  Copyright (c) 2015年 Craig Liao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreViewController : UIViewController

@end
