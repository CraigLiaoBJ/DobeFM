//
//  UIView+Extension.h
//  DobeFM
//
//  Created by Craig Liao on 15/7/16.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Extension)

@property (nonatomic, retain) UIButton *button;

@end
