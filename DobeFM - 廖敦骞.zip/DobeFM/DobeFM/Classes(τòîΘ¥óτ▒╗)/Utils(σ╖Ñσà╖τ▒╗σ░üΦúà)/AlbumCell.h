//
//  AnchorAlumbCell.h
//  DobeFM
//
//  Created by Craig Liao on 15/7/21.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import "AlbumList.h"
@interface AlbumCell : UITableViewCell

@property (nonatomic, retain) SearchAlbum *searchAlbum;

@end
