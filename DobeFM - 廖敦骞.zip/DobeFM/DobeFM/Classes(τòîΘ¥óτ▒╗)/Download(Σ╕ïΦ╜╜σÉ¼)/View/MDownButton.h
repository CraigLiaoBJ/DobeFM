//
//  MDownButton.h
//  Xmly
//
//  Created by lanou3g on 15/7/13.
//  Copyright (c) 2015年 lanou3g. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MDownButton : UIButton
@property (nonatomic , assign) float starNum;

@property (nonatomic , assign) float endNum;
@end
