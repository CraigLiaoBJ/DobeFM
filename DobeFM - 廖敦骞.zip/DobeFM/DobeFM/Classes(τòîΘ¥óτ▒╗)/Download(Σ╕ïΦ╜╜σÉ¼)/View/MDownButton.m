//
//  MDownButton.m
//  Xmly
//
//  Created by lanou3g on 15/7/13.
//  Copyright (c) 2015年 lanou3g. All rights reserved.
//

#import "MDownButton.h"

@implementation MDownButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
