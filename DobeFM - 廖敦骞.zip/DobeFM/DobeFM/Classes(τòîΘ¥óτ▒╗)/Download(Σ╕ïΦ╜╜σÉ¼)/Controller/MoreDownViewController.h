//
//  MoreDownViewController.h
//  Xmly
//
//  Created by lanou3g on 15/7/9.
//  Copyright (c) 2015年 lanou3g. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreDownViewController : UIViewController
@property (nonatomic, strong) NSMutableArray *audioArray;

-(void)reloadView;
@end
