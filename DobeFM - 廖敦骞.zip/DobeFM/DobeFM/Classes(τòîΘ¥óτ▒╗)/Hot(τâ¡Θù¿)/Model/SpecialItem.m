//
//  SpecialItem.m
//  iTing
//
//  Created by Craig Liao on 15/7/4.
//  Copyright (c) 2015年 Craig Liao. All rights reserved.
//

#import "SpecialItem.h"

@implementation SpecialItem


- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
}
@end
