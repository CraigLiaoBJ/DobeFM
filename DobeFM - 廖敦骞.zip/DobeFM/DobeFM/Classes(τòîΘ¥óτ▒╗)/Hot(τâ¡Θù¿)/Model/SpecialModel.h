//
//  SpecialModel.h
//  DobeFM
//
//  Created by Craig Liao on 15/7/19.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SpecialModel : NSObject
//专题
@property (nonatomic, copy) NSString *coverPathSmall;
@property (nonatomic, copy) NSString *title;
@end
