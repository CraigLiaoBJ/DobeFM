//
//  HotViewController.h
//  
//
//  Created by Craig Liao on 15/7/2.
//
//

#import <UIKit/UIKit.h>

@interface HotViewController : UIViewController

@end
