//
//  AnchorInfoTableViewController.h
//  DobeFM
//
//  Created by Craig Liao on 15/7/15.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnchorInfoTableViewController : UITableViewController

@property (nonatomic, copy) NSString *anchorId;

@end
