//
//  HotAlbumCell.h
//  DobeFM
//
//  Created by Craig Liao on 15/7/20.
//  Copyright (c) 2015年 DobeFM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HotAlbumsModel.h"
@interface HotAlbumCell : UITableViewCell

@property (nonatomic, retain) HotAlbumsModel *hotAlbumsModel;

@end
